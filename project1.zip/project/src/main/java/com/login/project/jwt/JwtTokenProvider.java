package com.login.project.jwt;


//import java.sql.Date;
import java.util.Date;

import org.springframework.stereotype.Component;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;	
	

	@Component
	public class JwtTokenProvider {

	   
		public String secretKey="1234";
//
//	   
	    private long validityInMilliseconds=3600000;
	    private static int jwtExpirationMs = 7200000;

	    public String createToken(String email) {
//	        Date now = new Date();
//	        Date validity = new Date(now.getTime() + validityInMilliseconds);

	        return Jwts.builder()
	                .setSubject(email)
	                .setIssuedAt(new Date())
	                .setExpiration(new Date(new Date().getTime() + jwtExpirationMs))
	                .signWith(SignatureAlgorithm.HS256, secretKey)
	                .compact();
	    }
	    
//	    private static final byte[] jwtSecret = Keys.secretKeyFor(SignatureAlgorithm.HS512).getEncoded();
//	    private static int jwtExpirationMs = 7200000;
//	    
//		public static String generateJwtToken(String userId) { 
//	        return Jwts.builder()
//	                .setSubject((userId))
//	                .setIssuedAt(new Date())
//	                .setExpiration(new Date(new Date().getTime() + jwtExpirationMs))
//	                .signWith(SignatureAlgorithm.HS256, secretKey)
//	                .compact();
//	    }
	}


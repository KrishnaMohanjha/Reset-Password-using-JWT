package com.login.project.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.login.project.entity.User;
import com.login.project.repository.UserRepository;

@Service
public class UserService {

	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private PasswordEncoder passwordencoder;
	
	public User  getRegister(User user)
	{
		String encodedPassword = passwordencoder.encode(user.getPassword());
		user.setPassword(encodedPassword);
		return userRepository.save(user);
		
	}


	    public boolean getLogin(String email, String password) {
	    	System.out.println("test1"+email);
	        User user = userRepository.findByEmail(email);
	        System.out.println("test2"+user);
	        if (user != null && passwordencoder.matches(password, user.getPassword())) {
	            return true;
	        }
	        
	        
	        return false; 
	    }

		private String getPassword() {
			
			return null;
		}
}
